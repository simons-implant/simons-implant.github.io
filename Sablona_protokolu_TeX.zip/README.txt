Šablona protokolu obsahuje 3 samostatné soubory k vyplnění od studenta:

1) udaje_v_hlavicce.tex ... zde student vyplní své jméno, příjmení atd.
2) vypracovani.tex      ... do tohoto souboru provede samotné vypracování protokolu a
3) literatura.bib       ... pro případné citace.

Věřím, že do ostatních souborů není třeba zasahovat, ale pokud je potřeba, tak samozřejmě můžete.